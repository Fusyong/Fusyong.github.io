<map version="freeplane 1.7.0">
<!--To view this file, download free mind mapping software Freeplane from http://freeplane.sourceforge.net -->
<node TEXT="pgzero&#x6587;&#x6863;" FOLDED="false" ID="ID_1448864441" CREATED="1574476945481" MODIFIED="1574491161830" STYLE="oval">
<font SIZE="18"/>
<hook NAME="MapStyle" zoom="1.128">
    <properties fit_to_viewport="false" show_icon_for_attributes="true" show_note_icons="true" edgeColorConfiguration="#808080ff,#ff0000ff,#0000ffff,#00ff00ff,#ff00ffff,#00ffffff,#7c0000ff,#00007cff,#007c00ff,#7c007cff,#007c7cff,#7c7c00ff"/>

<map_styles>
<stylenode LOCALIZED_TEXT="styles.root_node" STYLE="oval" UNIFORM_SHAPE="true" VGAP_QUANTITY="24.0 pt">
<font SIZE="24"/>
<stylenode LOCALIZED_TEXT="styles.predefined" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="default" ICON_SIZE="12.0 pt" COLOR="#000000" STYLE="fork">
<font NAME="SansSerif" SIZE="10" BOLD="false" ITALIC="false"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.details"/>
<stylenode LOCALIZED_TEXT="defaultstyle.attributes">
<font SIZE="9"/>
</stylenode>
<stylenode LOCALIZED_TEXT="defaultstyle.note" COLOR="#000000" BACKGROUND_COLOR="#ffffff" TEXT_ALIGN="LEFT"/>
<stylenode LOCALIZED_TEXT="defaultstyle.floating">
<edge STYLE="hide_edge"/>
<cloud COLOR="#f0f0f0" SHAPE="ROUND_RECT"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.user-defined" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="styles.topic" COLOR="#18898b" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subtopic" COLOR="#cc3300" STYLE="fork">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.subsubtopic" COLOR="#669900">
<font NAME="Liberation Sans" SIZE="10" BOLD="true"/>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.important">
<icon BUILTIN="yes"/>
</stylenode>
</stylenode>
<stylenode LOCALIZED_TEXT="styles.AutomaticLayout" POSITION="right" STYLE="bubble">
<stylenode LOCALIZED_TEXT="AutomaticLayout.level.root" COLOR="#000000" STYLE="oval" SHAPE_HORIZONTAL_MARGIN="10.0 pt" SHAPE_VERTICAL_MARGIN="10.0 pt">
<font SIZE="18"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,1" COLOR="#0033ff">
<font SIZE="16"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,2" COLOR="#00b439">
<font SIZE="14"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,3" COLOR="#990000">
<font SIZE="12"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,4" COLOR="#111111">
<font SIZE="10"/>
</stylenode>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,5"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,6"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,7"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,8"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,9"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,10"/>
<stylenode LOCALIZED_TEXT="AutomaticLayout.level,11"/>
</stylenode>
</stylenode>
</map_styles>
</hook>
<hook NAME="AutomaticEdgeColor" COUNTER="12" RULE="ON_BRANCH_CREATION"/>
<edge STYLE="sharp_bezier"/>
<node TEXT="# &#x5165;&#x95e8;&#x793a;&#x4f8b;&#xa;intro/" POSITION="right" ID="ID_1573869472" CREATED="1574477028141" MODIFIED="1574597946349">
<edge STYLE="sharp_bezier" COLOR="#ff0000"/>
<node TEXT="intro.py" ID="ID_29865589" CREATED="1574477390746" MODIFIED="1574592347393">
<edge STYLE="sharp_bezier"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <div style="color: #d4d4d4; background-color: #1e1e1e; font-family: Consolas, Courier New, monospace, &#x7b49;&#x7ebf;, Consolas, Courier New, monospace; font-weight: normal; font-size: 14px; line-height: 19px; white-space: pre">
      <div>
        <span style="color: #6a9955"><font color="#6a9955">#&#160;&#23548;&#20837;pgzero&#30340;&#27169;&#22359;&#36816;&#34892;&#24037;&#20855;pgzrun&#65292;&#19982;&#27169;&#22359;&#26368;&#21518;&#30340;`pgzrun.go()`&#37197;&#21512;&#20351;&#29992;</font></span>
      </div>
      <div>
        <span style="color: #6a9955"><font color="#6a9955">#&#160;&#25928;&#26524;&#30456;&#24403;&#20110;&#22312;&#21629;&#20196;&#34892;&#20013;&#36816;&#34892;`pgzrun&#160;intro.py`</font></span>
      </div>
      <div>
        <span style="color: #6a9955"><font color="#6a9955">#&#160;Mu&#21644;Thonny&#30340;`Pygame&#160;Zero&#27169;&#24335;`&#36816;&#34892;&#65292;&#21363;&#26159;&#25191;&#34892;`pgzrun&#160;intro.py`&#21629;&#20196;</font></span>
      </div>
      <div>
        <span style="color: #569cd6"><font color="#569cd6">import</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">&#160;pgzrun</font></span>
      </div>
      <div>
        <span style="color: #6a9955"><font color="#6a9955">#&#160;from&#160;pgzero&#160;import&#160;Actor</font></span>
      </div>
      <div>
        <span style="color: #569cd6"><font color="#569cd6">import</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">&#160;time</font></span>
      </div>
      <br/>
      <br/>
      

      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">WIDTH&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #b5cea8"><font color="#b5cea8">300</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">HEIGHT&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #b5cea8"><font color="#b5cea8">300</font></span>
      </div>
      <br/>
      

      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">alien&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;Actor(</span></font><span style="color: #ce9178"><font color="#ce9178">'alien'</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">)</font></span>
      </div>
      <div>
        <span style="color: #6a9955"><font color="#6a9955">#&#160;alien.pos&#160;=&#160;100,&#160;56</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">alien.topright&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #b5cea8"><font color="#b5cea8">0</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">,&#160;</font></span><span style="color: #b5cea8"><font color="#b5cea8">10</font></span>
      </div>
      <br/>
      

      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">WIDTH&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #b5cea8"><font color="#b5cea8">500</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">HEIGHT&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;alien.height&#160;</span><span style="color: #d4d4d4">+</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #b5cea8"><font color="#b5cea8">20</font></span>
      </div>
      <br/>
      

      <div>
        <span style="color: #569cd6"><font color="#569cd6">def</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">&#160;draw():</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;screen.clear()</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;screen.fill((</font></span><span style="color: #b5cea8"><font color="#b5cea8">128</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">,&#160;</font></span><span style="color: #b5cea8"><font color="#b5cea8">0</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">,&#160;</font></span><span style="color: #b5cea8"><font color="#b5cea8">0</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">))</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;alien.draw()</font></span>
      </div>
      <br/>
      

      <div>
        <span style="color: #569cd6"><font color="#569cd6">def</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">&#160;update():</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;alien.left&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">+=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #b5cea8"><font color="#b5cea8">2</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;</font></span><span style="color: #569cd6"><font color="#569cd6">if</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">&#160;alien.left&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">&gt;</span><span style="color: #d4d4d4">&#160;WIDTH:</span></font>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.right&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #b5cea8"><font color="#b5cea8">0</font></span>
      </div>
      <br/>
      

      <div>
        <span style="color: #569cd6"><font color="#569cd6">def</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">&#160;on_mouse_down(pos):</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;</font></span><span style="color: #569cd6"><font color="#569cd6">if</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">&#160;alien.collidepoint(pos):</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sounds.eep.play()</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.image&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #ce9178"><font color="#ce9178">'alien_hurt'</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;time.sleep(</font></span><span style="color: #b5cea8"><font color="#b5cea8">0.1</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">)</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.image&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #ce9178"><font color="#ce9178">'alien'</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;set_alien_hurt()</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;</font></span><span style="color: #569cd6"><font color="#569cd6">else</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">:</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;print(</font></span><span style="color: #ce9178"><font color="#ce9178">&quot;You&#160;missed&#160;me!&quot;</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">)</font></span>
      </div>
      <br/>
      

      <div>
        <span style="color: #569cd6"><font color="#569cd6">def</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">&#160;set_alien_hurt():</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;alien.image&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #ce9178"><font color="#ce9178">'alien_hurt'</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;sounds.eep.play()</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;clock.schedule_unique(set_alien_normal,&#160;</font></span><span style="color: #b5cea8"><font color="#b5cea8">1.0</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">)</font></span>
      </div>
      <br/>
      

      <div>
        <span style="color: #569cd6"><font color="#569cd6">def</font></span><span style="color: #d4d4d4"><font color="#d4d4d4">&#160;set_alien_normal():</font></span>
      </div>
      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">&#160;&#160;&#160;&#160;alien.image&#160;</font></span><font color="#d4d4d4"><span style="color: #d4d4d4">=</span><span style="color: #d4d4d4">&#160;</span></font><span style="color: #ce9178"><font color="#ce9178">'alien'</font></span>
      </div>
      <br/>
      

      <div>
        <span style="color: #d4d4d4"><font color="#d4d4d4">pgzrun.go()&#160; </font></span>
      </div>
    </div>
  </body>
</html>
</richcontent>
<node TEXT="import pgzrun" ID="ID_1936044093" CREATED="1574485124606" MODIFIED="1574596591510" TEXT_SHORTENED="true">
<edge STYLE="sharp_bezier"/>
<hook URI="pgzrun.png" SIZE="0.63761955" NAME="ExternalObject"/>
<richcontent TYPE="DETAILS">

<html>
  <head>
    
  </head>
  <body>
    <p>
      pgzrun&#23558;&#33258;&#21160;&#24341;&#20837;
    </p>
    <p>
      * &#31867;&#65306;Actor, Rect, ZRect
    </p>
    <p>
      * &#23545;&#35937;&#65306;images, keyboard, screen, sounds
    </p>
    <p>
      * &#26522;&#20030;&#23545;&#35937;&#65306;keymods, keys, mouse
    </p>
    <p>
      * &#20989;&#25968;&#65306;animate(), exit()
    </p>
    <p>
      * &#27169;&#22359;&#65306;clock, music, pgzrun, tone
    </p>
  </body>
</html>

</richcontent>
</node>
<node TEXT="def draw()" ID="ID_1067072643" CREATED="1574482883877" MODIFIED="1574592596547">
<edge STYLE="sharp_bezier"/>
</node>
<node TEXT="def update()" ID="ID_627282253" CREATED="1574482898513" MODIFIED="1574491161831">
<edge STYLE="sharp_bezier"/>
</node>
<node TEXT="def on_mouse_down()" ID="ID_1522698478" CREATED="1574483025147" MODIFIED="1574491161831">
<edge STYLE="sharp_bezier"/>
</node>
<node TEXT="pgzrun.go()" ID="ID_133893678" CREATED="1574484949309" MODIFIED="1574491161831">
<edge STYLE="sharp_bezier"/>
</node>
</node>
<node TEXT="images/" ID="ID_1789655521" CREATED="1574477363175" MODIFIED="1574491161831">
<edge STYLE="sharp_bezier"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#26631;&#20934;&#30446;&#24405;&#12290;pgzero&#20250;&#33258;&#21160;&#20174;&#36825;&#37324;&#25214;&#22270;&#20687;&#25991;&#20214;
    </p>
  </body>
</html>
</richcontent>
<node TEXT="alien.png" ID="ID_930522112" CREATED="1574477587825" MODIFIED="1574491161832">
<edge STYLE="sharp_bezier"/>
</node>
<node TEXT="alien_hurt.png" ID="ID_469188552" CREATED="1574477604838" MODIFIED="1574491161832">
<edge STYLE="sharp_bezier"/>
</node>
</node>
<node TEXT="sounds/" ID="ID_716808352" CREATED="1574477371771" MODIFIED="1574491161832">
<edge STYLE="sharp_bezier"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#26631;&#20934;&#30446;&#24405;&#12290;pgzero&#20250;&#33258;&#21160;&#20174;&#36825;&#37324;&#25214;&#38899;&#39057;&#25991;&#20214;
    </p>
  </body>
</html>
</richcontent>
<node TEXT="eep.wav" ID="ID_1270569867" CREATED="1574477627512" MODIFIED="1574491161832">
<edge STYLE="sharp_bezier"/>
</node>
</node>
</node>
<node TEXT="Migrating from Scratch&#xff08;&#x7565;&#xff09;" POSITION="right" ID="ID_1721683486" CREATED="1574490384685" MODIFIED="1574599730706">
<edge STYLE="sharp_bezier" COLOR="#007c00"/>
</node>
<node TEXT="# &#x4e8b;&#x4ef6;&#x94a9;&#x5b50;&#xa;Event Hooks" POSITION="right" ID="ID_1913266559" CREATED="1574483420297" MODIFIED="1574597978573">
<edge STYLE="sharp_bezier" COLOR="#00ff00"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Pygame Zero will automatically pick up and call event hooks that you define. This approach saves you from having to implement the event loop machinery yourself.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="# &#x6e38;&#x620f;&#x5faa;&#x73af;&#x94a9;&#x5b50;&#xa;Game Loop Hooks" ID="ID_1669273794" CREATED="1574483665679" MODIFIED="1574597988189">
<edge STYLE="sharp_bezier"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      A typical game loop looks a bit like this:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;while game_has_not_ended():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;process_input()
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;update()
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;draw()
    </p>
    <p>
      
    </p>
    <p>
      Input processing is a bit more complicated, but Pygame Zero allows you to easily define the update() and draw() functions within your game module.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="draw()" ID="ID_1275853619" CREATED="1574483691750" MODIFIED="1574491161832">
<edge STYLE="sharp_bezier"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Called by Pygame Zero when it needs to redraw your game window.
    </p>
    <p>
      
    </p>
    <p>
      draw() must take no arguments.
    </p>
    <p>
      
    </p>
    <p>
      Pygame Zero attempts to work out when the game screen needs to be redrawn to avoid redrawing if nothing has changed. On each step of the game loop it will draw the screen in the following situations:
    </p>
    <p>
      
    </p>
    <p>
      * If you have defined an update() function (see below).
    </p>
    <p>
      * If a clock event fires.
    </p>
    <p>
      * If an input event has been triggered.
    </p>
    <p>
      
    </p>
    <p>
      One way this can catch you out is if you attempt to modify or animate something within the draw function. For example, this code is wrong: the alien is not guaranteed to continue moving across the screen:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def draw():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.left += 1
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.draw()
    </p>
    <p>
      
    </p>
    <p>
      The correct code uses update() to modify or animate things and draw simply to paint the screen:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def draw():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.draw()
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def update():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.left += 1
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="update() or update(dt)" ID="ID_786428074" CREATED="1574483718970" MODIFIED="1574491161832">
<edge STYLE="sharp_bezier"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Called by Pygame Zero to step your game logic. This will be called repeatedly, 60 times a second.
    </p>
    <p>
      
    </p>
    <p>
      There are two different approaches to writing an update function.
    </p>
    <p>
      
    </p>
    <p>
      In simple games you can assume a small time step (a fraction of a second) has elapsed between each call to update(). Perhaps you don&#8217;t even care how big that time step is: you can just move objects by a fixed number of pixels per frame (or accelerate them by a fixed constant, etc.)
    </p>
    <p>
      
    </p>
    <p>
      A more advanced approach is to base your movement and physics calculations on the actual amount of time that has elapsed between calls. This can give smoother animation, but the calculations involved can be harder and you must take more care to avoid unpredictable behaviour when the time steps grow larger.
    </p>
    <p>
      
    </p>
    <p>
      To use a time-based approach, you can change the update function to take a single parameter. If your update function takes an argument, Pygame Zero will pass it the elapsed time in seconds. You can use this to scale your movement calculations.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="# &#x4e8b;&#x4ef6;&#x5904;&#x7406;&#x94a9;&#x5b50;&#xa;Event Handling Hooks" ID="ID_1752073471" CREATED="1574483744401" MODIFIED="1574597996413">
<edge STYLE="sharp_bezier"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Similar to the game loop hooks, your Pygame Zero program can respond to input events by defining functions with specific names.
    </p>
    <p>
      
    </p>
    <p>
      Somewhat like in the case of update(), Pygame Zero will inspect your event handler functions to determine how to call them. So you don&#8217;t need to make your handler functions take arguments. For example, Pygame Zero will be happy to call any of these variations of an on_mouse_down function:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def on_mouse_down():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;print(&quot;Mouse button clicked&quot;)
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def on_mouse_down(pos):
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;print(&quot;Mouse button clicked at&quot;, pos)
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def on_mouse_down(button):
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;print(&quot;Mouse button&quot;, button, &quot;clicked&quot;)
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def on_mouse_down(pos, button):
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;print(&quot;Mouse button&quot;, button, &quot;clicked at&quot;, pos)
    </p>
    <p>
      
    </p>
    <p>
      It does this by looking at the names of the parameters, so they must be spelled exactly as above. Each event hook has a different set of parameters that you can use, as described below.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
<node TEXT="on_mouse_down()" ID="ID_1821908513" CREATED="1574484139347" MODIFIED="1574484547116"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      # on_mouse_down ( [ _pos_ ] [ , _button_ ] )
    </p>
    <p>
      Called when a mouse button is depressed.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="on_mouse_up()" ID="ID_213424574" CREATED="1574484210200" MODIFIED="1574484550533"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      # on_mouse_up ( [ _pos_ ] [ , _button_ ] )
    </p>
    <p>
      Called when a mouse button is released.
    </p>
    <p>
      
    </p>
    <p>
      Parameters:
    </p>
    <p>
      &#160;&#160;* **pos** &#8211; A tuple (x, y) that gives the location of the mouse pointer when the button was released.
    </p>
    <p>
      &#160;&#160;* **button** &#8211; A [mouse][1] enum value indicating the button that was released.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="on_mouse_move()" ID="ID_494572004" CREATED="1574484260362" MODIFIED="1574484553956"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      # on_mouse_move ( [ _pos_ ] [ , _rel_ ] [ , _buttons_ ] )
    </p>
    <p>
      Called when the mouse is moved.
    </p>
    <p>
      
    </p>
    <p>
      Parameters:
    </p>
    <p>
      &#160;&#160;* **pos** &#8211; A tuple (x, y) that gives the location that the mouse pointer moved to.
    </p>
    <p>
      &#160;&#160;* **rel** &#8211; A tuple (delta_x, delta_y) that represent the change in the mouse pointer&#8217;s position.
    </p>
    <p>
      &#160;&#160;* **buttons** &#8211; A set of [mouse][1] enum values indicating the buttons that were depressed during the move.
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      To handle mouse drags, use code such as the following:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def on_mouse_move(rel, buttons):
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;if mouse.LEFT in buttons:
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;# the mouse was dragged, do something with `rel`
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;...
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="on_key_down()" ID="ID_1477594728" CREATED="1574484274390" MODIFIED="1574484557575"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      # on_key_down ( [ _key_ ] [ , _mod_ ] [ , _unicode_ ] )
    </p>
    <p>
      Called when a key is depressed.
    </p>
    <p>
      
    </p>
    <p>
      Parameters:
    </p>
    <p>
      &#160;&#160;* **key** &#8211; An integer indicating the key that was pressed (see [below][5]).
    </p>
    <p>
      &#160;&#160;* **unicode** &#8211; Where relevant, the character that was typed. Not all keys will result in printable characters # many may be control characters. In the event that a key doesn&#8217;t correspond to a Unicode character, this will be the empty string.
    </p>
    <p>
      &#160;&#160;* **mod** &#8211; A bitmask of modifier keys that were depressed.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="on_key_up()" ID="ID_148299979" CREATED="1574484327975" MODIFIED="1574484561599"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      # on_key_up ( [ _key_ ] [ , _mod_ ] )
    </p>
    <p>
      Called when a key is released.
    </p>
    <p>
      
    </p>
    <p>
      Parameters:
    </p>
    <p>
      &#160;&#160;* **key** &#8211; An integer indicating the key that was released (see [below][5]).
    </p>
    <p>
      &#160;&#160;* **mod** &#8211; A bitmask of modifier keys that were depressed.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="on_music_end()" ID="ID_599481626" CREATED="1574484362170" MODIFIED="1574484568424"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      # on_music_end ( )
    </p>
    <p>
      Called when a [music track][8] finishes.
    </p>
    <p>
      
    </p>
    <p>
      Note that this will not be called if the track is configured to loop.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="#&#x5185;&#x5efa;&#x5bf9;&#x8c61;&#xa;Built-in Objects" POSITION="right" ID="ID_1185558019" CREATED="1574484779984" MODIFIED="1574598039684">
<edge STYLE="sharp_bezier" COLOR="#ff00ff"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Pygame Zero provides useful built-in objects to help you make games easily.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="# Buttons and Keys" FOLDED="true" ID="ID_1286402196" CREATED="1574490051107" MODIFIED="1574599483837">
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1752073471" STARTINCLINATION="344;0;" ENDINCLINATION="344;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<arrowlink SHAPE="CUBIC_CURVE" COLOR="#000000" WIDTH="2" TRANSPARENCY="200" FONT_SIZE="9" FONT_FAMILY="SansSerif" DESTINATION="ID_1906920102" STARTINCLINATION="337;0;" ENDINCLINATION="337;0;" STARTARROW="NONE" ENDARROW="DEFAULT"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Built-in objects mouse and keys can be used to determine which buttons or keys were pressed in the above events.
    </p>
    <p>
      
    </p>
    <p>
      Note that mouse scrollwheel events appear as button presses with the below WHEEL_UP/WHEEL_DOWN button constants.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="mouse: enum" FOLDED="true" ID="ID_1021027977" CREATED="1574490078910" MODIFIED="1574596831205"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      A built-in enumeration of buttons that can be received by the on_mouse_* handlers.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
<node TEXT="LEFT" ID="ID_1105797282" CREATED="1574490127819" MODIFIED="1574490166764"/>
<node TEXT="MIDDLE" ID="ID_609203589" CREATED="1574490166766" MODIFIED="1574490166767"/>
<node TEXT="RIGHT" ID="ID_1986309072" CREATED="1574490166766" MODIFIED="1574490166766"/>
<node TEXT="WHEEL_UP" ID="ID_547019587" CREATED="1574490166765" MODIFIED="1574490166766"/>
<node TEXT="WHEEL_DOWN" ID="ID_305326345" CREATED="1574490166764" MODIFIED="1574490166765"/>
</node>
<node TEXT="keys: enum" FOLDED="true" ID="ID_361725557" CREATED="1574490169846" MODIFIED="1574596838445"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      A built-in enumeration of keys that can be received by the on_key_* handlers.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
<node TEXT="BACKSPACE" ID="ID_176771635" CREATED="1574490193950" MODIFIED="1574490239935"/>
<node TEXT="TAB" ID="ID_1159357226" CREATED="1574490240254" MODIFIED="1574490240258"/>
<node TEXT="CLEAR" ID="ID_1823529841" CREATED="1574490240249" MODIFIED="1574490240252"/>
<node TEXT="RETURN" ID="ID_1430773799" CREATED="1574490240242" MODIFIED="1574490240247"/>
<node TEXT="PAUSE" ID="ID_339843980" CREATED="1574490240237" MODIFIED="1574490240240"/>
<node TEXT="ESCAPE" ID="ID_1261909024" CREATED="1574490240231" MODIFIED="1574490240234"/>
<node TEXT="SPACE" ID="ID_822934216" CREATED="1574490240225" MODIFIED="1574490240228"/>
<node TEXT="EXCLAIM" ID="ID_253312899" CREATED="1574490240219" MODIFIED="1574490240222"/>
<node TEXT="QUOTEDBL" ID="ID_531223489" CREATED="1574490240213" MODIFIED="1574490240216"/>
<node TEXT="HASH" ID="ID_874539320" CREATED="1574490240207" MODIFIED="1574490240211"/>
<node TEXT="DOLLAR" ID="ID_450050678" CREATED="1574490240200" MODIFIED="1574490240205"/>
<node TEXT="AMPERSAND" ID="ID_714189053" CREATED="1574490240195" MODIFIED="1574490240198"/>
<node TEXT="QUOTE" ID="ID_1288194633" CREATED="1574490240189" MODIFIED="1574490240192"/>
<node TEXT="LEFTPAREN" ID="ID_706517085" CREATED="1574490240183" MODIFIED="1574490240187"/>
<node TEXT="RIGHTPAREN" ID="ID_835069574" CREATED="1574490240177" MODIFIED="1574490240180"/>
<node TEXT="ASTERISK" ID="ID_762696846" CREATED="1574490240171" MODIFIED="1574490240175"/>
<node TEXT="PLUS" ID="ID_875308578" CREATED="1574490240165" MODIFIED="1574490240169"/>
<node TEXT="COMMA" ID="ID_1441004101" CREATED="1574490240157" MODIFIED="1574490240160"/>
<node TEXT="MINUS" ID="ID_876416219" CREATED="1574490240150" MODIFIED="1574490240154"/>
<node TEXT="PERIOD" ID="ID_1944520409" CREATED="1574490240144" MODIFIED="1574490240148"/>
<node TEXT="SLASH" ID="ID_1069608462" CREATED="1574490240139" MODIFIED="1574490240142"/>
<node TEXT="K_0" ID="ID_181977015" CREATED="1574490240133" MODIFIED="1574490240136"/>
<node TEXT="K_1" ID="ID_115177757" CREATED="1574490240127" MODIFIED="1574490240130"/>
<node TEXT="K_2" ID="ID_631221308" CREATED="1574490240121" MODIFIED="1574490240124"/>
<node TEXT="K_3" ID="ID_625953773" CREATED="1574490240115" MODIFIED="1574490240118"/>
<node TEXT="K_4" ID="ID_1676140057" CREATED="1574490240110" MODIFIED="1574490240113"/>
<node TEXT="K_5" ID="ID_1813751193" CREATED="1574490240104" MODIFIED="1574490240107"/>
<node TEXT="K_6" ID="ID_1375682985" CREATED="1574490240098" MODIFIED="1574490240101"/>
<node TEXT="K_7" ID="ID_1213454892" CREATED="1574490240092" MODIFIED="1574490240096"/>
<node TEXT="K_8" ID="ID_843301275" CREATED="1574490240087" MODIFIED="1574490240090"/>
<node TEXT="K_9" ID="ID_421191605" CREATED="1574490240081" MODIFIED="1574490240084"/>
<node TEXT="COLON" ID="ID_1515370644" CREATED="1574490240075" MODIFIED="1574490240078"/>
<node TEXT="SEMICOLON" ID="ID_62201290" CREATED="1574490240069" MODIFIED="1574490240072"/>
<node TEXT="LESS" ID="ID_196919155" CREATED="1574490240063" MODIFIED="1574490240066"/>
<node TEXT="EQUALS" ID="ID_1490385422" CREATED="1574490240057" MODIFIED="1574490240060"/>
<node TEXT="GREATER" ID="ID_639361024" CREATED="1574490240051" MODIFIED="1574490240054"/>
<node TEXT="QUESTION" ID="ID_156362760" CREATED="1574490240042" MODIFIED="1574490240045"/>
<node TEXT="AT" ID="ID_911922952" CREATED="1574490240036" MODIFIED="1574490240039"/>
<node TEXT="LEFTBRACKET" ID="ID_1650403906" CREATED="1574490240030" MODIFIED="1574490240033"/>
<node TEXT="BACKSLASH" ID="ID_1729332784" CREATED="1574490240024" MODIFIED="1574490240027"/>
<node TEXT="RIGHTBRACKET" ID="ID_593588909" CREATED="1574490240018" MODIFIED="1574490240021"/>
<node TEXT="CARET" ID="ID_1314589334" CREATED="1574490240012" MODIFIED="1574490240015"/>
<node TEXT="UNDERSCORE" ID="ID_1806774257" CREATED="1574490240005" MODIFIED="1574490240009"/>
<node TEXT="BACKQUOTE" ID="ID_439614180" CREATED="1574490239999" MODIFIED="1574490240003"/>
<node TEXT="A" ID="ID_1262945779" CREATED="1574490239993" MODIFIED="1574490239997"/>
<node TEXT="B" ID="ID_406297993" CREATED="1574490239987" MODIFIED="1574490239990"/>
<node TEXT="C" ID="ID_1336489066" CREATED="1574490239980" MODIFIED="1574490239985"/>
<node TEXT="D" ID="ID_676889003" CREATED="1574490239970" MODIFIED="1574490239975"/>
<node TEXT="E" ID="ID_463200017" CREATED="1574490239961" MODIFIED="1574490239966"/>
<node TEXT="F" ID="ID_336911238" CREATED="1574490239949" MODIFIED="1574490239956"/>
<node TEXT="G" ID="ID_1843760787" CREATED="1574490239941" MODIFIED="1574490239946"/>
<node TEXT="H&#xa;I&#xa;J&#xa;K&#xa;L&#xa;M&#xa;N&#xa;O&#xa;P&#xa;Q&#xa;R&#xa;S&#xa;T&#xa;U&#xa;V&#xa;W&#xa;X&#xa;Y&#xa;Z&#xa;DELETE&#xa;KP0&#xa;KP1&#xa;KP2&#xa;KP3&#xa;KP4&#xa;KP5&#xa;KP6&#xa;KP7&#xa;KP8&#xa;KP9&#xa;KP_PERIOD&#xa;KP_DIVIDE&#xa;KP_MULTIPLY&#xa;KP_MINUS&#xa;KP_PLUS&#xa;KP_ENTER&#xa;KP_EQUALS&#xa;UP&#xa;DOWN&#xa;RIGHT&#xa;LEFT&#xa;INSERT&#xa;HOME&#xa;END&#xa;PAGEUP&#xa;PAGEDOWN&#xa;F1&#xa;F2&#xa;F3&#xa;F4&#xa;F5&#xa;F6&#xa;F7&#xa;F8&#xa;F9&#xa;F10&#xa;F11&#xa;F12&#xa;F13&#xa;F14&#xa;F15&#xa;NUMLOCK&#xa;CAPSLOCK&#xa;SCROLLOCK&#xa;RSHIFT&#xa;LSHIFT&#xa;RCTRL&#xa;LCTRL&#xa;RALT&#xa;LALT&#xa;RMETA&#xa;LMETA&#xa;LSUPER&#xa;RSUPER&#xa;MODE&#xa;HELP&#xa;PRINT&#xa;SYSREQ&#xa;BREAK&#xa;MENU&#xa;POWER&#xa;EURO&#xa;LAST" ID="ID_979445179" CREATED="1574490239044" MODIFIED="1574490239045"/>
</node>
<node TEXT="keymods: enum" FOLDED="true" ID="ID_488068198" CREATED="1574490247591" MODIFIED="1574596845589"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Constants representing modifier keys that may have been depressed during an on_key_up/on_key_down event.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="LSHIFT" ID="ID_1499425067" CREATED="1574490262863" MODIFIED="1574490279693"/>
<node TEXT="RSHIFT" ID="ID_27267962" CREATED="1574490279711" MODIFIED="1574490279712"/>
<node TEXT="SHIFT" ID="ID_1312313718" CREATED="1574490279710" MODIFIED="1574490279710"/>
<node TEXT="LCTRL" ID="ID_1561467967" CREATED="1574490279707" MODIFIED="1574490279710"/>
<node TEXT="RCTRL" ID="ID_822047818" CREATED="1574490279706" MODIFIED="1574490279707"/>
<node TEXT="CTRL" ID="ID_616454176" CREATED="1574490279705" MODIFIED="1574490279706"/>
<node TEXT="LALT" ID="ID_450608863" CREATED="1574490279704" MODIFIED="1574490279705"/>
<node TEXT="RALT" ID="ID_1374820165" CREATED="1574490279703" MODIFIED="1574490279704"/>
<node TEXT="ALT" ID="ID_886120202" CREATED="1574490279702" MODIFIED="1574490279703"/>
<node TEXT="LMETA" ID="ID_632281840" CREATED="1574490279701" MODIFIED="1574490279702"/>
<node TEXT="RMETA" ID="ID_1102036106" CREATED="1574490279700" MODIFIED="1574490279701"/>
<node TEXT="META" ID="ID_380114822" CREATED="1574490279697" MODIFIED="1574490279700"/>
<node TEXT="NUM" ID="ID_1312635691" CREATED="1574490279696" MODIFIED="1574490279697"/>
<node TEXT="CAPS" ID="ID_59443933" CREATED="1574490279696" MODIFIED="1574490279696"/>
<node TEXT="MODE" ID="ID_1395953586" CREATED="1574490279694" MODIFIED="1574490279695"/>
</node>
</node>
<node TEXT="screen: Screen" FOLDED="true" ID="ID_1792767094" CREATED="1574484798606" MODIFIED="1574589744366"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      The screen object represents your game screen.
    </p>
    <p>
      
    </p>
    <p>
      It is a thin wrapper around a Pygame surface that allows you to easily draw images to the screen (&#8220;blit&#8221; them).
    </p>
  </body>
</html>
</richcontent>
<node TEXT="surface: Surface" ID="ID_143244777" CREATED="1574485759811" MODIFIED="1574597820589"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      surface
    </p>
    <p>
      The raw Pygame surface that represents the screen buffer. You can use this for advanced graphics operations.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="clear()" ID="ID_246182195" CREATED="1574485901706" MODIFIED="1574485951839"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Reset the screen to black.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="fill()" ID="ID_10282" CREATED="1574485952338" MODIFIED="1574485980612"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      fill((red, green, blue))
    </p>
    <p>
      Fill the screen with a solid color.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="blit()" ID="ID_170482648" CREATED="1574485996835" MODIFIED="1574486012258"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      blit(image, (left, top))
    </p>
    <p>
      Draw the image to the screen at the given position.
    </p>
    <p>
      
    </p>
    <p>
      blit() accepts either a Surface or a string as its image parameter. If image is a str then the named image will be loaded from the images/ directory.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="draw" ID="ID_1838294457" CREATED="1574587221752" MODIFIED="1574587234247">
<node TEXT="line()" ID="ID_917379845" CREATED="1574486027268" MODIFIED="1574587317234"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      draw.line(start, end, (r, g, b))
    </p>
    <p>
      Draw a line from start to end.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="circle()" ID="ID_1448497937" CREATED="1574486056320" MODIFIED="1574587324166"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      draw.circle(pos, radius, (r, g, b))
    </p>
    <p>
      Draw the outline of a circle.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="filled_circle()" ID="ID_407884263" CREATED="1574486340468" MODIFIED="1574587330939"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      draw.filled_circle(pos, radius, (r, g, b))
    </p>
    <p>
      Draw a filled circle.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="rect()" ID="ID_510849061" CREATED="1574486377060" MODIFIED="1574587335374"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      draw.rect(rect, (r, g, b))
    </p>
    <p>
      Draw the outline of a rectangle.
    </p>
    <p>
      
    </p>
    <p>
      Takes a Rect.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="filled_rect()" ID="ID_1920129486" CREATED="1574486406737" MODIFIED="1574587340458"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      draw.filled_rect(rect, (r, g, b))
    </p>
    <p>
      Draw a filled rectangle.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="text()" ID="ID_1804328463" CREATED="1574486434740" MODIFIED="1574587345149"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      draw.text(text, [pos, ]**kwargs)
    </p>
    <p>
      Draw text.
    </p>
    <p>
      
    </p>
    <p>
      There&#8217;s an extremely rich API for positioning and formatting text; see Text Formatting for full details.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="Text Formatting" FOLDED="true" ID="ID_1143138746" CREATED="1574489644529" MODIFIED="1574489681096"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      The [Screen][0]&#8217;s draw.text() method has a very rich set of methods for position and formatting of text. Some examples:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;Text color&quot;, (50, 30), color=&quot;orange&quot;)
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;Font name and size&quot;, (20, 100), fontname=&quot;Boogaloo&quot;, fontsize=60)
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;Positioned text&quot;, topright=(840, 20))
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;Allow me to demonstrate wrapped text.&quot;, (90, 210), width=180, lineheight=1.5)
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;Outlined text&quot;, (400, 70), owidth=1.5, ocolor=(255,255,0), color=(0,0,0))
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;Drop shadow&quot;, (640, 110), shadow=(2,2), scolor=&quot;#202020&quot;)
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;Color gradient&quot;, (540, 170), color=&quot;red&quot;, gcolor=&quot;purple&quot;)
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;Transparency&quot;, (700, 240), alpha=0.1)
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;Vertical text&quot;, midleft=(40, 440), angle=90)
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;All together now:\nCombining the above options&quot;,
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;midbottom=(427,460), width=360, fontname=&quot;Boogaloo&quot;, fontsize=48,
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;color=&quot;#AAFF00&quot;, gcolor=&quot;#66AA00&quot;, owidth=1.5, ocolor=&quot;black&quot;, alpha=0.8)
    </p>
    <p>
      
    </p>
    <p>
      In its simplest usage, screen.draw.text requires the string you want to draw, and the position. You can either do this by passing coordinates as the second argument (which is the top left of where the text will appear), or use the positioning keyword arguments (described later):
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello world&quot;, (20, 100))
    </p>
    <p>
      
    </p>
    <p>
      screen.draw.text takes many optional keyword arguments, described below.
    </p>
    <p>
      
    </p>
    <p>
      [0]: builtins.html#screen
    </p>
  </body>
</html>
</richcontent>
<node TEXT="Font name and size" ID="ID_1675318579" CREATED="1574489690069" MODIFIED="1574489728033"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Fonts are loaded from a directory named fonts, in a similar way to the handling of images and sounds. Fonts must be in .ttf format. For example:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello world&quot;, (100, 100), fontname=&quot;Viga&quot;, fontsize=32)
    </p>
    <p>
      
    </p>
    <p>
      Keyword arguments:
    </p>
    <p>
      
    </p>
    <p>
      * fontname: filename of the font to draw. By default, use the system font.
    </p>
    <p>
      * fontsize: size of the font to use, in pixels. Defaults to 24.
    </p>
    <p>
      * antialias: whether to render with antialiasing. Defaults to True.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Color and background color" ID="ID_325681306" CREATED="1574489728413" MODIFIED="1574489750742"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello world&quot;, (100, 100), color=(200, 200, 200), background=&quot;gray&quot;)
    </p>
    <p>
      
    </p>
    <p>
      Keyword arguments:
    </p>
    <p>
      
    </p>
    <p>
      * color: foreground color to use. Defaults to white.
    </p>
    <p>
      * background: background color to use. Defaults to None.
    </p>
    <p>
      
    </p>
    <p>
      color (as well as background, ocolor, scolor, and gcolor) can be an (r, g, b) sequence such as (255,127,0), a pygame.Color object, a color name such as &quot;orange&quot;, an HTML hex color string such as &quot;#FF7F00&quot;, or a string representing a hex color number such as &quot;0xFF7F00&quot;.
    </p>
    <p>
      
    </p>
    <p>
      background can also be None, in which case the background is transparent. Unlike pygame.font.Font.render, it&#8217;s generally not more efficient to set a background color when calling screen.draw.text. So only specify a background color if you actually want one.
    </p>
    <p>
      
    </p>
    <p>
      Colors with alpha transparency are not supported (except for the special case of invisible text with outlines or drop shadows - see below). See the alpha keyword argument for transparency.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Positioning" ID="ID_931960458" CREATED="1574489751456" MODIFIED="1574489770832"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello world&quot;, midtop=(400, 0))
    </p>
    <p>
      
    </p>
    <p>
      Keyword arguments:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;top left bottom right
    </p>
    <p>
      &#160;&#160;&#160;&#160;topleft bottomleft topright bottomright
    </p>
    <p>
      &#160;&#160;&#160;&#160;midtop midleft midbottom midright
    </p>
    <p>
      &#160;&#160;&#160;&#160;center centerx centery
    </p>
    <p>
      
    </p>
    <p>
      Positioning keyword arguments behave like the corresponding properties of pygame.Rect. Either specify two arguments, corresponding to the horizontal and vertical positions of the box, or a single argument that specifies both.
    </p>
    <p>
      
    </p>
    <p>
      If the position is overspecified (e.g. both left and right are given), then extra specifications will be (arbitrarily but deterministically) discarded. For constrained text, see the section on screen.draw.textbox below.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Word wrap" ID="ID_1464297647" CREATED="1574489771021" MODIFIED="1574489800340"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;splitting\nlines&quot;, (100, 100))
    </p>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;splitting lines&quot;, (100, 100), width=60)
    </p>
    <p>
      
    </p>
    <p>
      Keyword arguments:
    </p>
    <p>
      
    </p>
    <p>
      * width: maximum width of the text to draw, in pixels. Defaults to None.
    </p>
    <p>
      * widthem: maximum width of the text to draw, in font-based em units. Defaults to None.
    </p>
    <p>
      * lineheight: vertical spacing between lines, in units of the font&#8217;s default line height. Defaults to 1.0.
    </p>
    <p>
      
    </p>
    <p>
      screen.draw.text will always wrap lines at newline ( \n) characters. If width or widthem is set, it will also try to wrap lines in order to keep each line shorter than the given width. The text is not guaranteed to be within the given width, because wrapping only occurs at space characters, so if a single word is too long to fit on a line, it will not be broken up. Outline and drop shadow are also not accounted for, so they may extend beyond the given width.
    </p>
    <p>
      
    </p>
    <p>
      You can prevent wrapping on a particular space with non-breaking space characters ( \u00A0).
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Text alignment" ID="ID_763817289" CREATED="1574489800684" MODIFIED="1574489821462"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello\nworld&quot;, bottomright=(500, 400), align=&quot;left&quot;)
    </p>
    <p>
      
    </p>
    <p>
      Keyword argument:
    </p>
    <p>
      
    </p>
    <p>
      * align: horizontal positioning of lines with respect to each other. Defaults to None.
    </p>
    <p>
      
    </p>
    <p>
      align determines how lines are positioned horizontally with respect to each other, when more than one line is drawn. Valid values for align are the strings &quot;left&quot;, &quot;center&quot;, or &quot;right&quot;, a numerical value between 0.0 (for left alignment) and 1.0 (for right alignment), or None.
    </p>
    <p>
      
    </p>
    <p>
      If align is None, the alignment is determined based on other arguments, in a way that should be what you want most of the time. It depends on any positioning arguments ( topleft, centerx, etc.), anchor, and finally defaults to &quot;left&quot;. I suggest you generally trust the default alignment, and only specify align if something doesn&#8217;t look right.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Outline" ID="ID_824967285" CREATED="1574489821841" MODIFIED="1574489838375"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello world&quot;, (100, 100), owidth=1, ocolor=&quot;blue&quot;)
    </p>
    <p>
      
    </p>
    <p>
      Keyword arguments:
    </p>
    <p>
      
    </p>
    <p>
      * owidth: outline thickness, in outline units. Defaults to None.
    </p>
    <p>
      * ocolor: outline color. Defaults to &quot;black&quot;.
    </p>
    <p>
      
    </p>
    <p>
      The text will be outlined if owidth is specified. The outlining is a crude manual method, and will probably look bad at large sizes. The units of owidth are chosen so that 1.0 is a good typical value for outlines. Specifically, they&#8217;re the font size divided by 24.
    </p>
    <p>
      
    </p>
    <p>
      As a special case, setting color to a transparent value (e.g. (0,0,0,0)) while using outilnes will cause the text to be invisible, giving a hollow outline. (This feature is not compatible with gcolor.)
    </p>
    <p>
      
    </p>
    <p>
      Valid values for ocolor are the same as for color.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Drop shadow" ID="ID_17333092" CREATED="1574489838907" MODIFIED="1574489857167"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      screen.draw.text(&quot;hello world&quot;, (100, 100), shadow=(1.0,1.0), scolor=&quot;blue&quot;)
    </p>
    <p>
      Keyword arguments:
    </p>
    <p>
      
    </p>
    <p>
      shadow: (x,y) values representing the drop shadow offset, in shadow units. Defaults to None.
    </p>
    <p>
      scolor: drop shadow color. Defaults to &quot;black&quot;.
    </p>
    <p>
      The text will have a drop shadow if shadow is specified. It must be set to a 2-element sequence representing the x and y offsets of the drop shadow, which can be positive, negative, or 0. For example, shadow=(1.0,1.0) corresponds to a shadow down and to the right of the text. shadow=(0,-1.2) corresponds to a shadow higher than the text.
    </p>
    <p>
      
    </p>
    <p>
      The units of shadow are chosen so that 1.0 is a good typical value for the offset. Specifically, they&#8217;re the font size divided by 18.
    </p>
    <p>
      
    </p>
    <p>
      As a special case, setting color to a transparent value (e.g. (0,0,0,0)) while using drop shadow will cause the text to be invisible, giving a hollow shadow. (This feature is not compatible with gcolor.)
    </p>
    <p>
      
    </p>
    <p>
      Valid values for scolor are the same as for color.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Gradient color" ID="ID_451256880" CREATED="1574489857351" MODIFIED="1574489873923"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello world&quot;, (100, 100), color=&quot;black&quot;, gcolor=&quot;green&quot;)
    </p>
    <p>
      
    </p>
    <p>
      Keyword argument:
    </p>
    <p>
      
    </p>
    <p>
      * gcolor: Lower gradient stop color. Defaults to None.
    </p>
    <p>
      
    </p>
    <p>
      Specify gcolor to color the text with a vertical color gradient. The text&#8217;s color will be color at the top and gcolor at the bottom. Positioning of the gradient stops and orientation of the gradient are hard coded and cannot be specified.
    </p>
    <p>
      
    </p>
    <p>
      Requries pygame.surfarray module, which uses numpy or Numeric library.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Alpha transparency" ID="ID_1338112181" CREATED="1574489874108" MODIFIED="1574489889591"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello world&quot;, (100, 100), alpha=0.5)
    </p>
    <p>
      
    </p>
    <p>
      Keyword argument:
    </p>
    <p>
      
    </p>
    <p>
      * alpha: alpha transparency value, between 0 and 1. Defaults to 1.0.
    </p>
    <p>
      
    </p>
    <p>
      In order to maximize reuse of cached transparent surfaces, the value of alpha is rounded.
    </p>
    <p>
      
    </p>
    <p>
      Requires pygame.surfarray module, which uses numpy or Numeric library.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Anchored positioning" ID="ID_899706109" CREATED="1574489891350" MODIFIED="1574489908695"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello world&quot;, (100, 100), anchor=(0.3,0.7))
    </p>
    <p>
      
    </p>
    <p>
      Keyword argument:
    </p>
    <p>
      
    </p>
    <p>
      * anchor: a length-2 sequence of horizontal and vertical anchor fractions. Defaults to (0.0,&#160;&#160;0.0).
    </p>
    <p>
      
    </p>
    <p>
      anchor specifies how the text is anchored to the given position, when no positioning keyword arguments are passed. The two values in anchor can take arbitrary values between 0.0 and 1.0. An anchor value of (0,0), the default, means that the given position is the top left of the text. A value of (1,1) means the given position is the bottom right of the text.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Rotation" ID="ID_1933214642" CREATED="1574489908878" MODIFIED="1574489928243"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.text(&quot;hello world&quot;, (100, 100), angle=10)
    </p>
    <p>
      
    </p>
    <p>
      Keyword argument:
    </p>
    <p>
      
    </p>
    <p>
      * angle: counterclockwise rotation angle in degrees. Defaults to 0.
    </p>
    <p>
      
    </p>
    <p>
      Positioning of rotated surfaces is tricky. When drawing rotated text, the anchor point, the position you actually specify, remains fixed, and the text rotates around it. For instance, if you specify the top left of the text to be at (100,&#160;&#160;100) with an angle of 90, then the Surface will actually be drawn so that its bottom left is at (100,&#160;&#160;100).
    </p>
    <p>
      
    </p>
    <p>
      If you find that confusing, try specifying the center. If you anchor the text at the center, then the center will remain fixed, no matter how you rotate it.
    </p>
    <p>
      
    </p>
    <p>
      In order to maximize reuse of cached rotated surfaces, the value of angle is rounded to the nearest multiple of 3 degrees.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Constrained text" ID="ID_1801417841" CREATED="1574489933719" MODIFIED="1574489945421"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;screen.draw.textbox(&quot;hello world&quot;, (100, 100, 200, 50))
    </p>
    <p>
      
    </p>
    <p>
      screen.draw.textbox requires two arguments: the text to be drawn, and a pygame.Rect or a Rect-like object to stay within. The font size will be chosen to be as large as possible while staying within the box. Other than fontsize and positional arguments, you can pass all the same keyword arguments to screen.draw.textbox as to screen.draw.text.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="textbox()" ID="ID_1575389973" CREATED="1574486455779" MODIFIED="1574587349677"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      draw.textbox(text, rect, **kwargs)
    </p>
    <p>
      Draw text, sized to fill the given Rect.
    </p>
    <p>
      
    </p>
    <p>
      There&#8217;s an extremely rich API for formatting text; see Text Formatting for full details.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Rect: class" ID="ID_62370344" CREATED="1574486499977" MODIFIED="1574598176220"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      The Pygame Rect class is available as a built in. This can be used in a variety of ways, from detecting clicks within a region to drawing a box onto the screen:
    </p>
    <p>
      
    </p>
    <p>
      For example, you can draw a box with:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;RED = 200, 0, 0
    </p>
    <p>
      &#160;&#160;&#160;&#160;BOX = Rect((20, 20), (100, 100))
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def draw():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;screen.draw.rect(BOX, RED)
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="# Resource Loading" FOLDED="true" ID="ID_1053163822" CREATED="1574486569566" MODIFIED="1574598059292"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      The images and sounds objects can be used to load images and sounds from files stored in the images and sounds subdirectories respectively. Pygame Zero will handle loading of these resources on demand and will cache them to avoid reloading them.
    </p>
    <p>
      
    </p>
    <p>
      You generally need to ensure that your images are named with lowercase letters, numbers and underscores only. They also have to start with a letter.
    </p>
    <p>
      
    </p>
    <p>
      File names like these will work well with the resource loader:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;alien.png
    </p>
    <p>
      &#160;&#160;&#160;&#160;alien_hurt.png
    </p>
    <p>
      &#160;&#160;&#160;&#160;alien_run_7.png
    </p>
    <p>
      
    </p>
    <p>
      These will not work:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;3.png
    </p>
    <p>
      &#160;&#160;&#160;&#160;3degrees.png
    </p>
    <p>
      &#160;&#160;&#160;&#160;my-cat.png
    </p>
    <p>
      &#160;&#160;&#160;&#160;sam's dog.png
    </p>
  </body>
</html>
</richcontent>
<node TEXT="images: ImageLoader" FOLDED="true" ID="ID_984656487" CREATED="1574486683049" MODIFIED="1574591553600"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Pygame Zero can load images in .png, .gif, and .jpg formats. PNG is recommended: it will allow high quality images with transparency.
    </p>
    <p>
      
    </p>
    <p>
      We need to ensure an images directory is set up. If your project contains the following files:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;space_game.py
    </p>
    <p>
      &#160;&#160;&#160;&#160;images/alien.png
    </p>
    <p>
      
    </p>
    <p>
      Then space_game.py could draw the &#8216;alien&#8217; sprite to the screen with this code:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def draw():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;screen.clear()
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;screen.blit('alien', (10, 10))
    </p>
    <p>
      
    </p>
    <p>
      The name passed to blit() is the name of the image file within the images directory, without the file extension.
    </p>
    <p>
      
    </p>
    <p>
      Or using the Actors API,
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;alien = Actor('alien')
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def draw():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.draw()
    </p>
    <p>
      
    </p>
    <p>
      There are some restrictions on the file names in both cases: they may only contain lowercase latin letters, numbers and underscores. This is to prevent compatibility problems when your game is played on a different operating system that has different case sensitivity.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="image_name: Surface" ID="ID_1943145009" CREATED="1574486799062" MODIFIED="1574595352190"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      You can also load images from the images directory using the images object. This allows you to work with the image data itself, query its dimensions and so on:
    </p>
    <p>
      
    </p>
    <p>
      forest = []
    </p>
    <p>
      for i in range(5):
    </p>
    <p>
      &#160;&#160;&#160;&#160;forest.append(
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;Actor('tree', topleft=(images.tree.width * i, 0))
    </p>
    <p>
      &#160;&#160;&#160;&#160;)
    </p>
    <p>
      Each loaded image is a Pygame Surface. You will typically use screen.blit(...) to draw this to the screen. It also provides handy methods to query the size of the image in pixels:
    </p>
  </body>
</html>

</richcontent>
<node TEXT="get_width()" ID="ID_1093668669" CREATED="1574486988314" MODIFIED="1574487000175"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Returns the width of the image in pixels.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="get_height()" ID="ID_944371526" CREATED="1574487001363" MODIFIED="1574487027622"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Returns the height of the image in pixels.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="get_size()" ID="ID_1816195174" CREATED="1574487028638" MODIFIED="1574487049699"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Returns a tuple (width, height) indicating the size in pixels of the surface.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="get_rect()" ID="ID_1181972515" CREATED="1574487051274" MODIFIED="1574487090686"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Get a Rect that is pre-populated with the bounds of the image if the image was located at the origin.
    </p>
    <p>
      
    </p>
    <p>
      Effectively this is equivalent to:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;Rect((0, 0), image.get_size())
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="sounds: SoundLoader" FOLDED="true" ID="ID_1826828784" CREATED="1574487119295" MODIFIED="1574591569128"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Pygame Zero can load sounds in .wav and .ogg formats. WAV is great for small sound effects, while OGG is a compressed format that is more suited to music. You can find free .ogg and .wav files online that can be used in your game.
    </p>
    <p>
      
    </p>
    <p>
      We need to ensure a sounds directory is set up. If your project contains the following files:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;drum_kit.py
    </p>
    <p>
      &#160;&#160;&#160;&#160;sounds/drum.wav
    </p>
    <p>
      
    </p>
    <p>
      Then drum_kit.py could play the drum sound whenever the mouse is clicked with this code:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def on_mouse_down():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;sounds.drum.play()
    </p>
    <p>
      
    </p>
    <p>
      Each loaded sound is a Pygame Sound, and has various methods to play and stop the sound as well as query its length in seconds:
    </p>
    <p>
      
    </p>
    <p>
      &#8230;&#8230;
    </p>
    <p>
      
    </p>
    <p>
      You should avoid using the sounds object to play longer pieces of music. Because the sounds sytem will fully load the music into memory before playing it, this can use a lot of memory, as well as introducing a delay while the music is loaded.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="sound_name: Sound" ID="ID_491192778" CREATED="1574593414486" MODIFIED="1574593429455">
<node TEXT="play()" ID="ID_965795596" CREATED="1574487166537" MODIFIED="1574487196811"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Play the sound.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="play(loops)" ID="ID_1312498156" CREATED="1574487197359" MODIFIED="1574487233885"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Play the sound, but loop it a number of times.
    </p>
    <p>
      
    </p>
    <p>
      Parameters: loops &#8211; The number of times to loop. If you pass -1 as the number of times to loop, the sound will loop forever (or until you call Sound.stop()
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="stop()" ID="ID_356027649" CREATED="1574487248676" MODIFIED="1574487258874"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Stop playing the sound.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="get_length()" ID="ID_1361980097" CREATED="1574487259481" MODIFIED="1574487285442"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Get the duration of the sound in seconds.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</node>
<node TEXT="music: moudle" FOLDED="true" ID="ID_1518511117" CREATED="1574487377050" MODIFIED="1574598110752"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;New in version 1.1.
    </p>
    <p>
      
    </p>
    <p>
      Warning
    </p>
    <p>
      
    </p>
    <p>
      The music API is experimental and may be subject to cross-platform portability issues.
    </p>
    <p>
      
    </p>
    <p>
      In particular:
    </p>
    <p>
      
    </p>
    <p>
      * MP3 may not be available on some Linux distributions.
    </p>
    <p>
      * Some OGG Vorbis files seem to hang Pygame with 100% CPU.
    </p>
    <p>
      
    </p>
    <p>
      In the case of the latter issue, the problem may be fixed by re-encoding (possibly with a different encoder).
    </p>
    <p>
      
    </p>
    <p>
      A built-in object called music provides access to play music from within a music/ directory (alongside your images/ and sounds/ directories, if you have them). The music system will load the track a little bit at a time while the music plays, avoiding the problems with using sounds to play longer tracks.
    </p>
    <p>
      
    </p>
    <p>
      Another difference to the sounds system is that only one music track can be playing at a time. If you play a different track, the previously playing track will be stopped.
    </p>
    <p>
      
    </p>
    <p>
      &#8230;&#8230;
    </p>
    <p>
      
    </p>
    <p>
      If you have started a music track playing using music.play_once(), you can use the on_music_end() hook to do something when the music ends - for example, to pick another track at random.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="play(name)" ID="ID_331469836" CREATED="1574487439481" MODIFIED="1574598224700"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Play a music track from the given file. The track will loop indefinitely.
    </p>
    <p>
      
    </p>
    <p>
      This replaces the currently playing track and cancels any tracks previously queued with queue().
    </p>
    <p>
      
    </p>
    <p>
      You do not need to include the extension in the track name; for example, to play the file handel.mp3 on a loop:
    </p>
    <p>
      
    </p>
    <p>
      music.play('handel')
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="play_once(name)" ID="ID_1082427854" CREATED="1574487457105" MODIFIED="1574598229844"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Similar to play(), but the music will stop after playing through once.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="queue(name)" ID="ID_1583179298" CREATED="1574487477730" MODIFIED="1574598237676"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Similar to play_once(), but instead of stopping the current music, the track will be queued to play after the current track finishes (or after any other previously queued tracks).
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="stop()" ID="ID_376645013" CREATED="1574487511224" MODIFIED="1574598242540"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Stop the music.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="pause()" ID="ID_1514121683" CREATED="1574487519738" MODIFIED="1574598248364"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Pause the music temporarily. It can be resumed by calling unpause().
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="unpause()" ID="ID_1148810730" CREATED="1574487534340" MODIFIED="1574598253060"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Unpause the music.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="is_playing()" ID="ID_974167591" CREATED="1574487561008" MODIFIED="1574598257364"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Returns True if the music is playing (and is not paused), False otherwise.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="fadeout(duration)" ID="ID_526314363" CREATED="1574487570990" MODIFIED="1574598261492"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Fade out and eventually stop the current music playback.
    </p>
    <p>
      
    </p>
    <p>
      Parameters: duration &#8211; The duration in seconds over which the sound will be faded out. For example, to fade out over half a second, call music.fadeout(0.5).
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="set_volume(volume)" ID="ID_1795397765" CREATED="1574487590366" MODIFIED="1574598265564"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Set the volume of the music system.
    </p>
    <p>
      
    </p>
    <p>
      This takes a number between 0 (meaning silent) and 1 (meaning full volume).
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="get_volume()" ID="ID_113114821" CREATED="1574487621597" MODIFIED="1574598269884"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Get the current volume of the music system.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="clock: Clock" FOLDED="true" ID="ID_921551384" CREATED="1574487790817" MODIFIED="1574598300756"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Often when writing a game, you will want to schedule some game event to occur at a later time. For example, we may want a big boss alien to appear after 60 seconds. Or perhaps a power-up will appear every 20 seconds.
    </p>
    <p>
      
    </p>
    <p>
      More subtle are the situations when you want to delay some action for a shorter period. For example you might have a laser weapon that takes 1 second to charge up.
    </p>
    <p>
      
    </p>
    <p>
      We can use the clock object to schedule a function to happen in the future.
    </p>
    <p>
      
    </p>
    <p>
      Let&#8217;s start by defining a function fire_laser that we want to run in the future:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def fire_laser():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;lasers.append(player.pos)
    </p>
    <p>
      
    </p>
    <p>
      Then when the fire button is pressed, we will ask the clock to call it for us after exactly 1 second:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def on_mouse_down():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;clock.schedule(fire_laser, 1.0)
    </p>
    <p>
      
    </p>
    <p>
      Note that fire_laser is the function itself; without parentheses, it is not being called here! The clock will call it for us.
    </p>
    <p>
      
    </p>
    <p>
      (It is a good habit to write out times in seconds with a decimal point, like 1.0. This makes it more obvious when you are reading it back, that you are referring to a time value and not a count of things.)
    </p>
    <p>
      
    </p>
    <p>
      clock provides the following useful methods:
    </p>
    <p>
      
    </p>
    <p>
      &#8230;&#8230;
    </p>
    <p>
      
    </p>
    <p>
      Note that the Pygame Zero clock only holds weak references to each callback you give it. It will not fire scheduled events if the objects and methods are not referenced elsewhere. This can help prevent the clock keeping objects alive and continuing to fire unexpectedly after they are otherwise dead.
    </p>
    <p>
      
    </p>
    <p>
      The downside to the weak references is that you won&#8217;t be able to schedule lambdas or any other object that has been created purely to be scheduled. You will have to keep a reference to the object.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="schedule()" ID="ID_1264466448" CREATED="1574487864118" MODIFIED="1574487931968"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      schedule(callback, delay)
    </p>
    <p>
      Schedule callback to be called after the given delay.
    </p>
    <p>
      
    </p>
    <p>
      Repeated calls will schedule the callback repeatedly.
    </p>
    <p>
      
    </p>
    <p>
      Parameters:
    </p>
    <p>
      callback &#8211; A callable that takes no arguments.
    </p>
    <p>
      delay &#8211; The delay, in seconds, before the function should be called.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="schedule_unique()" ID="ID_19623540" CREATED="1574487934248" MODIFIED="1574487965463"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      schedule_unique(callback, delay)
    </p>
    <p>
      Schedule callback to be called once after the given delay.
    </p>
    <p>
      
    </p>
    <p>
      If callback was already scheduled, cancel and reschedule it. This applies also if it was scheduled multiple times: after calling schedule_unique, it will be scheduled exactly once.
    </p>
    <p>
      
    </p>
    <p>
      Parameters:
    </p>
    <p>
      callback &#8211; A callable that takes no arguments.
    </p>
    <p>
      delay &#8211; The delay, in seconds, before the function should be called.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="schedule_interval()" ID="ID_1188306286" CREATED="1574487966548" MODIFIED="1574487995163"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      schedule_interval(callback, interval)
    </p>
    <p>
      Schedule callback to be called repeatedly.
    </p>
    <p>
      
    </p>
    <p>
      Parameters:
    </p>
    <p>
      callback &#8211; A callable that takes no arguments.
    </p>
    <p>
      interval &#8211; The interval in seconds between calls to callback.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="unschedule()" ID="ID_592007472" CREATED="1574487999974" MODIFIED="1574488022465"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      unschedule(callback)
    </p>
    <p>
      Unschedule callback if it has been previously scheduled (either because it has been scheduled with schedule() and has not yet been called, or because it has been scheduled to repeat with schedule_interval().
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Actor: class" FOLDED="true" ID="ID_1325112211" CREATED="1574488341542" MODIFIED="1574598316548"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Once you have many images moving around in a game it can be convenient to have something that holds in one place the image and where it is on screen. We&#8217;ll call each moving image on screen an Actor. You can create an actor by supplying at least an image name (from the images folder above). To draw the alien talked about above:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;alien = Actor('alien', (50, 50))
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def draw():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;screen.clear()
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.draw()
    </p>
    <p>
      
    </p>
    <p>
      You can move the actor around by setting its pos attribute in an update:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def update():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;if keyboard.left:
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.x -= 1
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;elif keyboard.right:
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.x += 1
    </p>
    <p>
      
    </p>
    <p>
      And you may change the image used to draw the actor by setting its image attribute to some new image name:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;alien.image = 'alien_hurt'
    </p>
    <p>
      
    </p>
    <p>
      Actors have all the same attributes and methods as Rect, including methods like .colliderect() which can be used to test whether two actors have collided.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="# Positioning Actors" FOLDED="true" ID="ID_720158179" CREATED="1574488442055" MODIFIED="1574598497503"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      If you assign a new value to one of the position attributes then the actor will be moved. For example:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;alien.right = WIDTH
    </p>
    <p>
      
    </p>
    <p>
      will position the alien so its right-hand side is set to WIDTH.
    </p>
    <p>
      
    </p>
    <p>
      Similarly, you can also set the initial position of the actor in the constructor, by passing one of these as a keyword argument: pos, topleft, topright, bottomleft, bottomright, midtop, midleft, midright, midbottom or center:
    </p>
    <p>
      
    </p>
    <p>
      ![_images/anchor_points.png][0]
    </p>
    <p>
      
    </p>
    <p>
      This can be done during creation or by assigning a pair of x, y co-ordinates. For example:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;WIDTH = 200
    </p>
    <p>
      &#160;&#160;&#160;&#160;HEIGHT = 200
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;alien = Actor('alien', center=(100,100))
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def draw():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;screen.clear()
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;alien.draw()
    </p>
    <p>
      
    </p>
    <p>
      ![_images/alien_center.png][1]
    </p>
    <p>
      
    </p>
    <p>
      Changing center=(100,&#160;&#160;100) to midbottom=(100,&#160;&#160;200) gives you:
    </p>
    <p>
      
    </p>
    <p>
      ![_images/alien_midbottom.png][2]
    </p>
    <p>
      
    </p>
    <p>
      If you don&#8217;t specify an initial position, the actor will initially be positioned in the top-left corner (equivalent to topleft=(0,&#160;&#160;0)).
    </p>
    <p>
      
    </p>
    <p>
      [0]: _images/anchor_points.png
    </p>
    <p>
      [1]: _images/alien_center.png
    </p>
    <p>
      [2]: _images/alien_midbottom.png
    </p>
  </body>
</html>

</richcontent>
<node TEXT="pos" ID="ID_67285714" CREATED="1574598549393" MODIFIED="1574598962354"/>
<node TEXT="right" ID="ID_287330765" CREATED="1574598962386" MODIFIED="1574598962388"/>
<node TEXT="left" ID="ID_1666774258" CREATED="1574598962383" MODIFIED="1574598962385"/>
<node TEXT="bottom" ID="ID_312223029" CREATED="1574598962380" MODIFIED="1574598962383"/>
<node TEXT="top" ID="ID_1273230025" CREATED="1574598962378" MODIFIED="1574598962379"/>
<node TEXT="topleft" ID="ID_589480061" CREATED="1574598962375" MODIFIED="1574598962377"/>
<node TEXT="topright" ID="ID_738512933" CREATED="1574598962371" MODIFIED="1574598962375"/>
<node TEXT="bottomleft" ID="ID_312740030" CREATED="1574598962369" MODIFIED="1574598962370"/>
<node TEXT="bottomright" ID="ID_1169489439" CREATED="1574598962366" MODIFIED="1574598962368"/>
<node TEXT="midtop" ID="ID_490717428" CREATED="1574598962364" MODIFIED="1574598962366"/>
<node TEXT="midleft" ID="ID_1349104511" CREATED="1574598962362" MODIFIED="1574598962364"/>
<node TEXT="midright" ID="ID_1109236583" CREATED="1574598962360" MODIFIED="1574598962362"/>
<node TEXT="midbottom" ID="ID_161088130" CREATED="1574598962359" MODIFIED="1574598962360"/>
<node TEXT="center" ID="ID_665305803" CREATED="1574598962356" MODIFIED="1574598962358"/>
</node>
<node TEXT="anchor # Anchor point" ID="ID_910159265" CREATED="1574488446923" MODIFIED="1574599167908"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Actors have an &#8220;anchor position&#8221;, which is a convenient way to position the actor in the scene. By default, the anchor position is the center, so the .pos attribute refers to the center of the actor (and so do the x and y coordinates). It&#8217;s common to want to set the anchor point to another part of the sprite (perhaps the feet - so that you can easily set the Actor to be &#8220;standing on&#8221; something):
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;alien = Actor('alien', anchor=('center', 'bottom'))
    </p>
    <p>
      &#160;&#160;&#160;&#160;spaceship = Actor('spaceship', anchor=(10, 50))
    </p>
    <p>
      
    </p>
    <p>
      anchor is specified as a tuple (xanchor,&#160;&#160;yanchor), where the values can be floats or the strings left, center/ middle, right, top or bottom as appropriate.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="angle # Rotation" ID="ID_97950203" CREATED="1574488446922" MODIFIED="1574599157212"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;New in version 1.2.
    </p>
    <p>
      
    </p>
    <p>
      The .angle attribute of an Actor controls the rotation of the sprite, in degrees, anticlockwise (counterclockwise).
    </p>
    <p>
      
    </p>
    <p>
      The centre of rotation is the Actor&#8217;s [anchor point][0].
    </p>
    <p>
      
    </p>
    <p>
      Note that this will change the width and height of the Actor.
    </p>
    <p>
      
    </p>
    <p>
      For example, to make an asteroid sprite spinning slowly anticlockwise in space:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;asteroid = Actor('asteroid', center=(300, 300))
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def update():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;asteroid.angle += 1
    </p>
    <p>
      
    </p>
    <p>
      To have it spin clockwise, we&#8217;d change update() to:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;def update():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;asteroid.angle -= 1
    </p>
    <p>
      
    </p>
    <p>
      As a different example, we could make an actor ship always face the mouse pointer. Because [angle_to()][1] returns 0 for &#8220;right&#8221;, the sprite we use for &#8220;ship&#8221; should face right:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;ship = Actor('ship')
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def on_mouse_move(pos):
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;ship.angle = ship.angle_to(pos)
    </p>
    <p>
      
    </p>
    <p>
      ![Diagram showing how to set up sprites for rotation with angle_to()][2]
    </p>
    <p>
      
    </p>
    <p>
      Remember that angles loop round, so 0 degrees == 360 degrees == 720 degrees. Likewise -180 degrees == 180 degrees.
    </p>
    <p>
      
    </p>
    <p>
      [0]: #anchor
    </p>
    <p>
      [1]: #Actor.angle_to
    </p>
    <p>
      [2]: _images/rotation.svg
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="# Distance and angle to" ID="ID_88860240" CREATED="1574488446921" MODIFIED="1574598355172"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Actors have convenient methods for calculating their distance or angle to other Actors or (x,&#160;&#160;y) coordinate pairs.
    </p>
    <p>
      
    </p>
    <p>
      - Actor.distance_to ( _target_ )
    </p>
    <p>
      Return the distance from this actor&#8217;s position to target, in pixels.
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      - Actor.angle_to ( _target_ )
    </p>
    <p>
      Return the angle from this actor&#8217;s position to target, in degrees.
    </p>
    <p>
      
    </p>
    <p>
      This will return a number between -180 and 180 degrees. Right is 0 degrees and the angles increase going anticlockwise.
    </p>
    <p>
      
    </p>
    <p>
      Therefore:
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;* Left is 180 degrees.
    </p>
    <p>
      &#160;&#160;* Up is 90 degrees.
    </p>
    <p>
      &#160;&#160;* Down is -90 degrees.
    </p>
  </body>
</html>

</richcontent>
<node TEXT="distance_to()" ID="ID_1391811762" CREATED="1574599208938" MODIFIED="1574599219699"/>
<node TEXT="angle_to()" ID="ID_602619094" CREATED="1574599220105" MODIFIED="1574599227299"/>
</node>
</node>
<node TEXT="keyboard: Keyboard" ID="ID_1906920102" CREATED="1574488369110" MODIFIED="1574596276710"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      You probably noticed that we used the keyboard in the above code. If you&#8217;d like to know what keys are pressed on the keyboard, you can query the attributes of the keyboard builtin. If, say, the left arrow is held down, then keyboard.left will be True, otherwise it will be False.
    </p>
    <p>
      
    </p>
    <p>
      There are attributes for every key; some examples:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;keyboard.a&#160;&#160;# The 'A' key
    </p>
    <p>
      &#160;&#160;&#160;&#160;keyboard.left&#160;&#160;# The left arrow key
    </p>
    <p>
      &#160;&#160;&#160;&#160;keyboard.rshift&#160;&#160;# The right shift key
    </p>
    <p>
      &#160;&#160;&#160;&#160;keyboard.kp0&#160;&#160;# The '0' key on the keypad
    </p>
    <p>
      &#160;&#160;&#160;&#160;keyboard.k_0&#160;&#160;# The main '0' key
    </p>
    <p>
      
    </p>
    <p>
      The full set of key constants is given in the [Buttons and Keys][0] documentation, but the attributes are lowercase, because these are variables not constants.
    </p>
    <p>
      
    </p>
    <p>
      Deprecated since version 1.1: Uppercase and prefixed attribute names (eg. keyboard.LEFT or keyboard.K_a) are now deprecated; use lowercase attribute names instead.
    </p>
    <p>
      
    </p>
    <p>
      New in version 1.1: You can now also query the state of the keys using the keyboard constants themselves:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;keyboard[keys.A]&#160;&#160;# True if the 'A' key is pressed
    </p>
    <p>
      &#160;&#160;&#160;&#160;keyboard[keys.SPACE]&#160;&#160;# True if the space bar is pressed
    </p>
    <p>
      
    </p>
    <p>
      [0]: hooks.html#buttons-and-keys
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="animate(): Animation" FOLDED="true" ID="ID_1799601273" CREATED="1574488418783" MODIFIED="1574599573163"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      You can animate most things in pygame using the builtin animate(). For example, to move an [Actor][0] from its current position on the screen to the position (100,&#160;&#160;100):
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;animate(alien, pos=(100, 100))
    </p>
    <p>
      
    </p>
    <p>
      - animate ( _object_, _tween='linear'_, _duration=1_, _on_finished=None_, _**targets_ ) [&#182;][1]
    </p>
    <p>
      Animate the attributes on object from their current value to that specified in the targets keywords.
    </p>
    <p>
      
    </p>
    <p>
      Parameters:
    </p>
    <p>
      &#160;&#160;* **tween** &#8211; The type of _tweening_ to use.
    </p>
    <p>
      &#160;&#160;* **duration** &#8211; The duration of the animation, in seconds.
    </p>
    <p>
      &#160;&#160;* **on_finished** &#8211; Function called when the animation finishes.
    </p>
    <p>
      &#160;&#160;* **targets** &#8211; The target values for the attributes to animate.
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      The tween argument can be one of the following:
    </p>
    <p>
      
    </p>
    <p>
      &#8216;linear&#8217; Animate at a constant speed from start to finish &#8216;accelerate&#8217; Start slower and accelerate to finish &#8216;decelerate&#8217; Start fast and decelerate to finish &#8216;accel_decel&#8217; Accelerate to mid point and decelerate to finish &#8216;end_elastic&#8217; Give a little wobble at the end &#8216;start_elastic&#8217; Have a little wobble at the start &#8216;both_elastic&#8217; Have a wobble at both ends &#8216;bounce_end&#8217; Accelerate to the finish and bounce there &#8216;bounce_start&#8217; Bounce at the start &#8216;bounce_start_end&#8217; Bounce at both ends
    </p>
    <p>
      
    </p>
    <p>
      The animate() function returns an Animation instance:
    </p>
    <p>
      
    </p>
    <p>
      [0]: #actor
    </p>
    <p>
      [1]: #animate
    </p>
  </body>
</html>
</richcontent>
<node TEXT="stop()" ID="ID_832342935" CREATED="1574489131702" MODIFIED="1574489268706"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      stop ( _complete=False_ )
    </p>
    <p>
      Stop the animation, optionally completing the transition to the final property values.
    </p>
    <p>
      
    </p>
    <p>
      Parameters:**complete** &#8211; Set the animated attribute to the target value.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="running" ID="ID_661369481" CREATED="1574489269856" MODIFIED="1574489282968"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      This will be True if the animation is running. It will be False when the duration has run or the stop() method was called before then.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="on_finished" ID="ID_1510027954" CREATED="1574489283328" MODIFIED="1574489303718"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      You may set this attribute to a function which will be called when the animation duration runs out. The on_finished argument to animate() also sets this attribute. It is not called when stop() is called. This function takes no arguments.
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="tone" FOLDED="true" ID="ID_1571817420" CREATED="1574488418782" MODIFIED="1574599775656"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      New in version 1.2.
    </p>
    <p>
      
    </p>
    <p>
      Pygame Zero can play tones using a built-in synthesizer.
    </p>
  </body>
</html>
</richcontent>
<node TEXT="play()" ID="ID_1177242434" CREATED="1574489340762" MODIFIED="1574596437389"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      - tone.play ( _pitch_, _duration_ )
    </p>
    <p>
      Play a note at the given pitch for the given duration.
    </p>
    <p>
      
    </p>
    <p>
      Duration is in seconds.
    </p>
    <p>
      
    </p>
    <p>
      The _pitch_ can be specified as a number in which case it is the frequency of the note in hertz.
    </p>
    <p>
      
    </p>
    <p>
      Alternatively, the pitch can be specified as a string representing a note name and octave. For example:
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;* 'E4' would be E in octave 4.
    </p>
    <p>
      &#160;&#160;* 'A#5' would be A-sharp in octave 5.
    </p>
    <p>
      &#160;&#160;* 'Bb3' would be B-flat in octave 3.
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      Creating notes, particularly long notes, takes time - up to several milliseconds. You can create your notes ahead of time so that this doesn&#8217;t slow your game down while it is running:
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="create()" ID="ID_1379958036" CREATED="1574489423829" MODIFIED="1574599775656"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      - tone.create ( _pitch_, _duration_ )
    </p>
    <p>
      Create and return a Sound object.
    </p>
    <p>
      
    </p>
    <p>
      The arguments are as for play(), above.
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      This could be used in a Pygame Zero program like this:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;beep = tone.create('A3', 0.5)
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def on_mouse_down():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;beep.play()
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
<node TEXT="Installing Pygame Zero" FOLDED="true" POSITION="right" ID="ID_1748384079" CREATED="1574488482096" MODIFIED="1574491482110">
<edge STYLE="sharp_bezier" COLOR="#00ffff"/>
<node TEXT="On desktop systems" ID="ID_1702491478" CREATED="1574491482113" MODIFIED="1574491496739"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;&#160;&#160;&#160;pip install pgzero
    </p>
    <p>
      
    </p>
    <p>
      This will also install Pygame. Pre-compiled Pygame packages are available to pip for Windows &amp; Linux (32-bit and 64-bit), and for Mac OS (64-bit only). If you have a different system, you&#8217;ll need to find a way to install pygame first.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="On Raspberry Pi" ID="ID_280408317" CREATED="1574491497159" MODIFIED="1574491513126"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      pgzero has been installed by default since the release of Raspbian Jessie in September 2015!
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
<node TEXT="Running Pygame Zero in IDLE and other IDEs" POSITION="right" ID="ID_449382322" CREATED="1574488487827" MODIFIED="1574491161833">
<edge STYLE="sharp_bezier" COLOR="#00007c"/>
<richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      &#160;New in version 1.2.
    </p>
    <p>
      
    </p>
    <p>
      Pygame Zero is usually run using a command such as:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;pgzrun my_program.py
    </p>
    <p>
      
    </p>
    <p>
      Certain programs, such as integrated development environments like IDLE and Edublocks, will only run python, not pgzrun.
    </p>
    <p>
      
    </p>
    <p>
      Pygame Zero includes a way of writing a full Python program that can be run using python. To do it, put
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;import pgzrun
    </p>
    <p>
      
    </p>
    <p>
      as the very first line of the Pygame Zero program, and put
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;pgzrun.go()
    </p>
    <p>
      
    </p>
    <p>
      as the very last line.
    </p>
    <p>
      
    </p>
    <p>
      ## Example
    </p>
    <p>
      
    </p>
    <p>
      Here is a Pygame Zero program that draws a circle. You can run this by pasting it into IDLE:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;import pgzrun
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;WIDTH = 800
    </p>
    <p>
      &#160;&#160;&#160;&#160;HEIGHT = 600
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;def draw():
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;screen.clear()
    </p>
    <p>
      &#160;&#160;&#160;&#160;&#160;&#160;&#160;&#160;screen.draw.circle((400, 300), 30, 'white')
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;
    </p>
    <p>
      &#160;&#160;&#160;&#160;pgzrun.go()
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="Other libraries like Pygame Zero&#xff08;&#x7565;&#xff09;" POSITION="right" ID="ID_525833482" CREATED="1574491417568" MODIFIED="1574491424359">
<edge COLOR="#7c7c00"/>
</node>
<node TEXT="Changelog" FOLDED="true" POSITION="right" ID="ID_691222375" CREATED="1574490508956" MODIFIED="1574491161833">
<edge STYLE="sharp_bezier" COLOR="#7c007c"/>
<node TEXT="1.2 - 2018-02-24" ID="ID_1075144215" CREATED="1574490557638" MODIFIED="1574490585736"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      New: [Actors can be rotated][0] by assigning to actor.angle
    </p>
    <p>
      New: Actors now have [angle_to()][1] and [distance_to()][2] methods.
    </p>
    <p>
      New: Actors are no longer subclasses of Rect, though they provide the same methods/properties. However they are now provided with floating point precision.
    </p>
    <p>
      New: tone.play() function to allow playing musical notes.
    </p>
    <p>
      New: pgzrun.go() to allow running Pygame Zero from an IDE (see [Running Pygame Zero in IDLE and other IDEs][3]).
    </p>
    <p>
      New: show joypad icon by default
    </p>
    <p>
      Examples: add Asteroids example game (thanks to Ian Salmons)
    </p>
    <p>
      Examples: add Flappy Bird example game
    </p>
    <p>
      Examples: add Tetra example game (thanks to David Bern)
    </p>
    <p>
      Docs: Add a logo, fonts and colours to the documentation.
    </p>
    <p>
      Docs: Documentation for the [anchor point system for Actors][4]
    </p>
    <p>
      Docs: Add [Migrating from Scratch][5] documentation
    </p>
    <p>
      Fix: on_mouse_move() did not correctly handle the buttons parameter.
    </p>
    <p>
      Fix: Error message when resource not found incorrectly named last extension searched.
    </p>
    <p>
      Fix: Drawing wrapped text would cause crashes.
    </p>
    <p>
      Fix: [animate()][6] now replaces animations of the same property, rather than creating two animations which fight.
    </p>
    <p>
      Updated ptext to a revision as of 2016-11-17.
    </p>
    <p>
      Removed: removed undocumented British English centrex, centrey, centre attribute aliases on ZRect (because they are not Rect-compatible).
    </p>
    <p>
      
    </p>
    <p>
      [0]: builtins.html#rotation
    </p>
    <p>
      [1]: builtins.html#Actor.angle_to
    </p>
    <p>
      [2]: builtins.html#Actor.distance_to
    </p>
    <p>
      [3]: ide-mode.html
    </p>
    <p>
      [4]: builtins.html#anchor
    </p>
    <p>
      [5]: from-scratch.html
    </p>
    <p>
      [6]: builtins.html#animate
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="1.1 - 2015-08-03" ID="ID_1644341634" CREATED="1574490603213" MODIFIED="1574490616999"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Added a spell checker that will point out hook or parameter names that have been misspelled when the program starts.
    </p>
    <p>
      New ZRect built-in class, API compatible with Rect, but which accepts coordinates with floating point precision.
    </p>
    <p>
      Refactor of built-in keyboard object to fix attribute case consistency. This also allows querying key state by keys constants, eg. keyboard[keys.LEFT].
    </p>
    <p>
      Provide much better information when sound files are in an unsupported format.
    </p>
    <p>
      screen.blit() now accepts an image name string as well as a Surface object, for consistency with Actor.
    </p>
    <p>
      Fixed a bug with non-focusable windows and other event bugs when running in a virtualenv on Mac OS X.
    </p>
    <p>
      Actor can now be positioned by any of its border points (eg. topleft, midright) directly in the constructor.
    </p>
    <p>
      Added additional example games in the examples/ directory.
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="1.0.2 - 2015-06-04" ID="ID_1890664691" CREATED="1574490617947" MODIFIED="1574490652956"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Fix: ensure compatibility with Python 3.2
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="1.0.1 - 2015-05-31" ID="ID_663659881" CREATED="1574490562349" MODIFIED="1574490676826"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      This is a bugfix release.
    </p>
    <p>
      
    </p>
    <p>
      * Fix: Actor is now positioned to the top left of the window if pos is unspecified, rather than appearing partially off-screen.
    </p>
    <p>
      * Fix: repeating clock events can now unschedule/reschedule themselves
    </p>
    <p>
      
    </p>
    <p>
      Previously a callback that tried to unschedule itself would have had no effect, because after the callback returns it was rescheduled by the clock.
    </p>
    <p>
      
    </p>
    <p>
      This applies also to schedule_unique.
    </p>
    <p>
      * Fix: runner now correctly displays tracebacks from user code
    </p>
    <p>
      * New: Eliminate redraws when nothing has changed
    </p>
    <p>
      
    </p>
    <p>
      Redraws will now happen only if:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;* &gt; The screen has not yet been drawn
    </p>
    <p>
      &#160;&#160;* &gt; You have defined an update() function
    </p>
    <p>
      &#160;&#160;* &gt; An input event has been fired
    </p>
    <p>
      &#160;&#160;* &gt; The clock has dispatched an event
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="1.0 - 2015-05-29" ID="ID_1555893864" CREATED="1574490678991" MODIFIED="1574490702533"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      New: Added anchor parameter to Actor, offering control over where its pos attribute refers to. By default it now refers to the center.
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      New: Added Ctrl-Q/&#8984;-Q as a hard-coded keyboard shortcut to exit a game.
    </p>
    <p>
      
    </p>
    <p>
      
    </p>
    <p>
      New: on_mouse_* and on_key_* receive IntEnum values as button and key parameters, respectively. This simplifies debugging and enables usage like:
    </p>
    <p>
      
    </p>
    <p>
      &#160;&#160;&#160;&#160;if button is button.LEFT:
    </p>
  </body>
</html>
</richcontent>
</node>
<node TEXT="1.0beta1 - 2015-05-19" ID="ID_144030501" CREATED="1574490702803" MODIFIED="1574490713819"><richcontent TYPE="DETAILS" HIDDEN="true">

<html>
  <head>
    
  </head>
  <body>
    <p>
      Initial public (preview) release.
    </p>
    <p>
      
    </p>
  </body>
</html>
</richcontent>
</node>
</node>
</node>
</map>
