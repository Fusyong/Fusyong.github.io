import time  # 导入time模块

import pgzrun  # 导入pgzero的模块运行工具pgzrun

# pgzrun会自动引入下列对象，但显式导入可以方便编辑器补全、提示
# * 类：Actor, Rect, ZRect
# * 对象：images, keyboard, screen, sounds
# * 枚举对象：keymods, keys, mouse
# * 函数：animate(), exit()
# * 模块：clock, music, pgzrun, tone
from pgzero.actor import Actor
from pgzero.loaders import sounds
from pgzero.clock import clock
from pgzero.screen import Screen
screen: Screen  # 类型标注
# from pgz_built_in_objects import *  # vscode使用Jedi时可以这样


WIDTH = 800  # 画布宽
HEIGHT = 800  # 画布高

alien = Actor('alien')  # 用images文件夹中的图像'alien'生成演员
alien.pos = 0, 400  # 定位

def draw():  # 绘制画面（显示钩子）
    screen.clear()  # 清屏
    screen.fill((128, 0, 128))  # 填色
    alien.draw()  # 绘制演员

def update():  # 更新数据（显示钩子）
    alien.left += 2  # 右移
    if alien.left > WIDTH:  # 如果超出屏幕右边界
        alien.right = 0  #  重新放到屏幕左侧外

def on_mouse_down(pos):  # 当鼠标按下（事件钩子）
    if alien.collidepoint(pos):  # 如果与鼠标位置碰撞
        time.sleep(0.1)  # 暂停
        set_alien_hurt()  # 调用函数
    else:
        print("You missed me!")  # 打印消息

def set_alien_hurt():  # 外星人被击中后的动作
    alien.image = 'alien_hurt'  # 换用图像'alien_hurt'
    sounds.eep.play()  # 播放sounds文件夹中的声音文件'eep'
    clock.schedule_unique(set_alien_normal, 1.0)  # 用定时器调用一次函数

def set_alien_normal():  # 外星人复原
    alien.image = 'alien'  # 换用原图

pgzrun.go()  # 用pgzrun运行本脚本
